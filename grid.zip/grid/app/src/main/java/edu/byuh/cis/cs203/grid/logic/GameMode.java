package edu.byuh.cis.cs203.grid.logic;

public enum GameMode {
    // two player modes
    ONE_PLAYER,
    TWO_PLAYER
}
