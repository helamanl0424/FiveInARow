package edu.byuh.cis.cs203.grid.logic;

public enum Player {
    X,
    O,
    BLANK,
    TIE
}