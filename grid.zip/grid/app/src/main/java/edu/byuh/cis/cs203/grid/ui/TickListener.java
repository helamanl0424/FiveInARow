package edu.byuh.cis.cs203.grid.ui;

public interface TickListener {
    /**
     * for other classes to connect
     */
    void onTick();
}
